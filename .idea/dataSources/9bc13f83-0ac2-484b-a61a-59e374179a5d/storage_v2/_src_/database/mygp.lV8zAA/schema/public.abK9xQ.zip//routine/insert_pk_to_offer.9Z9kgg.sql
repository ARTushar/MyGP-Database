create function insert_pk_to_offer() returns trigger
  language plpgsql
as
$$
begin
  insert into offers values (new.offer_id);
  return new;
end;
$$;

alter function insert_pk_to_offer() owner to postgres;

