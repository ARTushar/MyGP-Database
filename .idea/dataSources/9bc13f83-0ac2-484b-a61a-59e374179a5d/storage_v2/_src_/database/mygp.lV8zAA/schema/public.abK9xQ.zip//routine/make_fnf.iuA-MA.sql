create procedure make_fnf(number_by numeric, number_to numeric)
  language plpgsql
as
$$
declare
begin
    insert into fnf values(number_by, number_to);
    raise notice 'Successfully inserted the fnf';
    exception when others then
    raise notice 'Cannot insert the fnf';
end;
$$;

alter procedure make_fnf(numeric, numeric) owner to postgres;

