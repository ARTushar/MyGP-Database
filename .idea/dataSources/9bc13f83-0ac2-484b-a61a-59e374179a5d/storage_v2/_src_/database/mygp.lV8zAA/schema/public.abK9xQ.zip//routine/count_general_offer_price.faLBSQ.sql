create function count_general_offer_price(sms numeric, data numeric, talk numeric) returns numeric
  language plpgsql
as
$$
DECLARE
  PRICE NUMERIC;
  SMS_COST NUMERIC;
  DATA_COST NUMERIC;
  TALK_TIME_COST NUMERIC;
BEGIN
  SELECT CALL_RATE, SMS_RATE, DATA_RATE FROM PACKAGE INTO TALK_TIME_COST, SMS_COST, DATA_COST;
  PRICE := SMS_COST*4/5 * SMS + TALK_TIME_COST*4/5 * TALK + DATA_COST * 4/5 * DATA;
  RETURN PRICE;
end;

$$;

alter function count_general_offer_price(numeric, numeric, numeric) owner to postgres;

