create function find_recharge_last_date(amount numeric) returns numeric
  language plpgsql
as
$$
DECLARE
  VALID_DAYS NUMERIC;
    BEGIN
    IF(AMOUNT < 50) THEN
      VALID_DAYS := 30;
    ELSE VALID_DAYS := 60;
    end if;
    RETURN VALID_DAYS;
  end;
$$;

alter function find_recharge_last_date(numeric) owner to postgres;

