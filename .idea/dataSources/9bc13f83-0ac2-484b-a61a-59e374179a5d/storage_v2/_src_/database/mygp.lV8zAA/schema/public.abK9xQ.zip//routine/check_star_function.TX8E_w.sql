create function check_star_function() returns trigger
  language plpgsql
as
$$
declare
  total_usage_last3months numeric;
  prc numeric;
  curr_date timestamptz;
  str_id numeric;
  usage_tobe_star numeric;
  r cursor for
    select * from star;
  off_id cursor for
    select OFFER_ID from PURCHASE_OFFER
    where USER_ID = new.user_id and (curr_date - PURCHASE_DATE) < interval '1 day' * 90;
begin
  curr_date := now();
  total_usage_last3months := 0;

  for b in off_id
  loop
    select price into prc from internet_offer where offer_id = b.offer_id;
    total_usage_last3months := total_usage_last3months + prc;
  end loop;

  for a in r
  loop
    str_id := a.star_id;
    usage_tobe_star := a.average_uses;
    if total_usage_last3months >= usage_tobe_star then
      update users set STAR_ID = str_id where MOBILE_NUMBER = new.user_id;
      --return new;
      exit ;
      --raise notice 'haha he is ' || a.type;
    end if;
  end loop;
  return new;
end;
$$;

alter function check_star_function() owner to postgres;

