create procedure make_link(number_by numeric, number_to numeric)
  language plpgsql
as
$$
declare
begin
  insert into link values (number_by, number_to);
  raise notice 'Successfully inserted the link';
  exception when others then
  raise notice 'Cannot insert the link';

end;
$$;

alter procedure make_link(numeric, numeric) owner to postgres;

