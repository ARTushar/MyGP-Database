create procedure migrate_package(mob_number numeric, p_name character varying)
  language plpgsql
as
$$
declare
  p_id numeric;
begin
  select p_id from package where package_name = p_name into p_id;
  update users set package_id = p_id where mobile_number = mob_number;
end;

$$;

alter procedure migrate_package(numeric, varchar) owner to postgres;

